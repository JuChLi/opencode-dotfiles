---
description: Query MiniMax Coding Plan quota (保留 █░)
---
Use the myminimax tool to query MiniMax quota usage. Return the result as-is without modification.
